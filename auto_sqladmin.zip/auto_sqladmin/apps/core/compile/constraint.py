# -*- coding: utf-8 -*-
from sqlalchemy import UniqueConstraint, Index, ForeignKeyConstraint

from apps.core.models.entity import Entity


class DynamicConstraint:
    """动态约束"""

    @classmethod
    def compile(cls, entity):
        """编译"""
        raise NotImplementedError


class DynamicConstraintUnique(DynamicConstraint):
    """唯一约束"""

    @classmethod
    async def compile(cls, entity: Entity) -> list[UniqueConstraint]:
        """唯一约束"""
        constraints = []
        for c in entity.unique_constraints:
            if c.fields:
                constraints.append(UniqueConstraint(*[f.name for f in c.fields], name=c.name))
        return constraints


class DynamicConstraintIndex(DynamicConstraint):
    """索引"""

    @classmethod
    async def compile(cls, entity):
        """索引约束"""
        constraints = []
        for c in entity.index_constraints:
            if c.fields:
                constraints.append(Index(c.name, *[f.name for f in c.fields]))
        return constraints


class DynamicConstraintForeignKey(DynamicConstraint):
    """外键"""

    @classmethod
    async def compile(cls, entity: Entity) -> list[ForeignKeyConstraint]:
        """外键约束"""
        constraints = []
        for c in entity.foreignkey_constraints:
            refed_table_name = c.refed_field.entity.table.name
            constraints.append(ForeignKeyConstraint(
                [c.ref_field.name],
                [f"{refed_table_name}.{c.refed_field.name}"],
                onupdate=c.on_update and c.on_update.value,
                ondelete=c.on_delete and c.on_delete.value
            ))
        return constraints
