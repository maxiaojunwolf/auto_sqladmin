# -*- coding: utf-8 -*-
from sqlalchemy import select
from sqlalchemy.orm import joinedload

from apps.core.compile.column import get_dynamic_column
from apps.core.compile.constraint import DynamicConstraintUnique, DynamicConstraintIndex, DynamicConstraintForeignKey
from apps.core.compile.relship import DynamicRelship_NtoN, DynamicRelship_1toN, DynamicRelship_1to1
from apps.core.db import session_factory, DynamicBase
from apps.core.models.constraint import Unique_Constraint, Index_Constraint, ForeignKey_Constraint
from apps.core.models.entity import Entity
from apps.core.models.relship import RelShip


class LoadORM:
    """加载ORM"""

    @classmethod
    async def reset_dynamicbase(cls):
        """重置Base:由于register.mappers为弱引用，需要单独保存下生产的orm，避免被自动回收"""
        DynamicBase.metadata.clear()
        DynamicBase.registry.dispose(cascade=True)
        DynamicBase.orms = dict()

    @classmethod
    async def load_columns(cls, entity: Entity) -> dict:
        """生成列属性"""
        columns = {}
        for field in entity.fields:
            column = await get_dynamic_column(field)
            columns[field.name] = column
        return columns

    @classmethod
    async def load_constraints(cls, entity: Entity) -> list:
        """生成约束"""
        unique_constraints = await DynamicConstraintUnique.compile(entity)
        index_constraints = await DynamicConstraintIndex.compile(entity)
        foreignkey_constraints = await DynamicConstraintForeignKey.compile(entity)
        return unique_constraints + index_constraints + foreignkey_constraints

    @classmethod
    async def load_relships(cls, entity: Entity) -> dict:
        """加载关系对象"""
        relationships = {}
        for r in entity.relships:
            if r.link_entity_id != r.refed_entity_id:
                rel_ship = await DynamicRelship_NtoN.compile(r)
            else:
                if r.uselist:
                    rel_ship = await DynamicRelship_1toN.compile(r)
                else:
                    rel_ship = await DynamicRelship_1to1.compile(r)
            relationships[r.name] = rel_ship
        return relationships

    @classmethod
    def load_str_func(cls, orm):
        """设置__str__方法"""
        if getattr(orm, "name", None):
            orm.__str__ = lambda i: i.name
        elif getattr(orm, "id", None):
            orm.__str__ = lambda i: str(i.id)
        else:
            pass

    @classmethod
    async def _load(cls, entity):
        """动态生成orm"""
        # 动态生成列
        columns = await cls.load_columns(entity)
        # 动态生成约束
        constraints = await cls.load_constraints(entity)
        # 动态生成关系
        relships = await cls.load_relships(entity)
        kw = {"__tablename__": entity.table.name,
              "__table_args__": (*constraints,
                                 {"extend_existing": True}),
              "__is_dynamic__": True,
              # 保存动态类基本信息
              "__entity__": {"id": entity.id, "name": entity.name},
              **columns,
              **relships
              }
        orm = type(entity.name.capitalize(), (DynamicBase,), kw)
        cls.load_str_func(orm)
        return orm

    @classmethod
    async def load(cls):
        """动态生成ORM"""
        print("-----加载动态ORM-开始------")
        await cls.reset_dynamicbase()
        async with session_factory() as session:
            stmt = select(Entity).options(
                joinedload(Entity.table),
                joinedload(Entity.fields, innerjoin=True),
                joinedload(Entity.unique_constraints).joinedload(Unique_Constraint.fields),
                joinedload(Entity.index_constraints).joinedload(Index_Constraint.fields),
                joinedload(Entity.foreignkey_constraints).joinedload(ForeignKey_Constraint.ref_field),
                joinedload(Entity.foreignkey_constraints).joinedload(ForeignKey_Constraint.refed_field),
                joinedload(Entity.relships).joinedload(RelShip.ref_entity),
                joinedload(Entity.relships).joinedload(RelShip.link_entity),
                joinedload(Entity.relships).joinedload(RelShip.refed_entity)
            )
            result = await session.execute(stmt)
            for obj in result.unique().scalars():
                DynamicBase.orms[obj.name] = await cls._load(obj)
        print("-----加载动态ORM-完成------")
