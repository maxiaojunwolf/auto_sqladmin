# -*- coding: utf-8 -*-
from sqlalchemy import inspect

from apps.core.admin.base import CoreModelView
from apps.core.models.org import Organization, OrgType
from apps.core.tools import get_column_label


class OrgTypeAdmin(CoreModelView, model=OrgType):
    """组织类型"""
    # Internals
    category = "组织"
    # Metadata
    name = "组织类型"
    name_plural = "组织类型"
    icon = "fa-solid fa-gears"

    # List page
    column_list = ["id",
                   "name",
                   "label",
                   "create_date",
                   "update_date",
                   ]

    column_searchable_list = ["name"]
    column_sorrole_list = ["name"]
    column_default_sort = [("id", True)]

    # detail page
    column_details_list = ["id",
                           "name",
                           "label",
                           "creator",
                           "create_date",
                           "updater",
                           "update_date"]

    # General options 自动从ORM获取doc作为属性标签
    column_labels = {i: get_column_label(i) for i in inspect(OrgType).mapper.attrs}
    # Form options


class OrganizationAdmin(CoreModelView, model=Organization):
    """组织"""
    # Internals
    category = "组织"
    # Metadata
    name = "组织"
    name_plural = "组织"
    icon = "fa-solid fa-sitemap"

    # List page
    column_list = ["id",
                   "name",
                   "label",
                   "org_type",
                   "create_date",
                   "update_date",
                   ]

    column_searchable_list = ["name"]
    column_sororg_list = ["name"]
    column_default_sort = [("id", True)]

    # detail page
    column_details_list = ["id",
                           "name",
                           "label",
                           "org_type",
                           "creator",
                           "create_date",
                           "updater",
                           "update_date"]

    # General options 自动从ORM获取doc作为属性标签
    column_labels = {i: get_column_label(i) for i in inspect(Organization).mapper.attrs}
    # Form options
    form_widget_args_edit = {"name": {"readonly": True}}
    form_ajax_refs = {

        "org_type": {
            "fields": ("name",),
            "order_by": "name",
        }
    }
